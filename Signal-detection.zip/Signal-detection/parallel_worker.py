#!/usr/bin/env python
# coding: utf-8
"""
Parallel worker for model training. Called as subprocess by youhua_parallel.py.
Usage: python parallel_worker.py --model_name informer --data_path data.pt --result_path result.pt --model_params_path params.json ...
"""
import argparse
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import copy
import sys
import warnings
import os

# Suppress known harmless warnings
warnings.filterwarnings('ignore', message='enable_nested_tensor is True')
os.environ.setdefault('PYDEVD_DISABLE_FILE_VALIDATION', '1')

if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
if hasattr(sys.stderr, 'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

from torch.utils.data import Dataset, DataLoader

# =========================
# BitHistoryManager
# =========================
class BitHistoryManager:
    def __init__(self, true_bits, num_senders=3, mode='train'):
        self.true_bits = true_bits
        self.num_senders = num_senders
        self.num_seqs, self.seq_len = true_bits.shape if len(true_bits.shape) > 1 else (1, len(true_bits))
        if len(true_bits.shape) == 1:
            self.true_bits = true_bits.reshape(1, -1)
            self.num_seqs = 1
        self.mode = mode
        self.pred_bits = np.zeros_like(self.true_bits)
        if self.mode == 'test':
            self.pred_queues = [[] for _ in range(self.num_senders)]

    def reset(self):
        self.pred_bits = np.zeros_like(self.true_bits)
        if self.mode == 'test':
            self.pred_queues = [[] for _ in range(self.num_senders)]

    def get_prev_bits(self, j):
        if self.mode == 'train':
            prev_bits_flat = []
            for s in range(self.num_senders):
                prev_bits_flat.extend(self.true_bits[s, j-3:j].tolist())
            return np.array(prev_bits_flat)
        elif self.mode == 'test':
            if j >= 3 and len(self.pred_queues[0]) == 0:
                for s in range(self.num_senders):
                    self.pred_queues[s] = list(self.true_bits[s, 1:4])
            prev_bits_flat = []
            for s in range(self.num_senders):
                prev_bits_flat.extend(self.pred_queues[s])
            return np.array(prev_bits_flat)

    def save_prediction(self, j, pred_bit):
        if self.mode != 'test':
            return
        for s in range(self.num_senders):
            if 0 <= j < self.pred_bits.shape[1]:
                self.pred_bits[s, j] = pred_bit[s]
            if len(self.pred_queues[s]) >= 3:
                self.pred_queues[s].pop(0)
            self.pred_queues[s].append(pred_bit[s])

# =========================
# PositionalEncoding
# =========================
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(1)
        self.register_buffer('pe', pe)
    def forward(self, x):
        return x + self.pe[:x.size(0)]

# =========================
# Informer Components
# =========================
class ProbAttention(nn.Module):
    def __init__(self, mask_flag=True, factor=5, scale=None, attention_dropout=0.1, output_attention=False):
        super().__init__()
        self.factor, self.scale, self.mask_flag = factor, scale, mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)
    def forward(self, queries, keys, values, attn_mask=None):
        B, H, L_Q, D = queries.shape; _, _, L_K, _ = keys.shape
        U_part = min(self.factor * int(math.ceil(math.log(L_K + 1))), L_K)
        u = min(self.factor * int(math.ceil(math.log(L_Q + 1))), L_Q)
        index_sample = torch.randint(L_K, (L_Q, U_part), device=queries.device)
        K_sample = keys[:, :, index_sample, :]
        Q_K_sample = torch.matmul(queries.unsqueeze(-2), K_sample.transpose(-2, -1)).squeeze(-2)
        M = Q_K_sample.max(-1).values - Q_K_sample.mean(-1)
        M_top = M.topk(u, sorted=False).indices
        Q_reduce = queries.gather(dim=2, index=M_top.unsqueeze(-1).expand(-1, -1, -1, D))
        Q_K = torch.matmul(Q_reduce, keys.transpose(-2, -1))
        scale = self.scale or 1.0 / math.sqrt(D)
        scores = Q_K * scale; attn = torch.softmax(scores, dim=-1); attn = self.dropout(attn)
        context_update = torch.matmul(attn, values)
        context = values.mean(dim=-2).unsqueeze(-2).expand(B, H, L_Q, D).clone()
        context.scatter_(dim=2, index=M_top.unsqueeze(-1).expand(-1, -1, -1, D), src=context_update)
        return context, None

class AttentionLayer(nn.Module):
    def __init__(self, attention, d_model, n_heads):
        super().__init__()
        d_keys = d_values = d_model // n_heads
        self.inner_attention = attention
        self.query_projection = nn.Linear(d_model, d_keys * n_heads)
        self.key_projection = nn.Linear(d_model, d_keys * n_heads)
        self.value_projection = nn.Linear(d_model, d_values * n_heads)
        self.out_projection = nn.Linear(d_values * n_heads, d_model)
        self.n_heads, self.d_keys, self.d_values = n_heads, d_keys, d_values
    def forward(self, queries, keys, values):
        L, B, _ = queries.shape; H = self.n_heads
        q = self.query_projection(queries).view(L, B, H, self.d_keys).permute(1, 2, 0, 3)
        k = self.key_projection(keys).view(L, B, H, self.d_keys).permute(1, 2, 0, 3)
        v = self.value_projection(values).view(L, B, H, self.d_values).permute(1, 2, 0, 3)
        out, attn = self.inner_attention(q, k, v)
        out = out.permute(2, 0, 1, 3).contiguous().view(L, B, -1)
        return self.out_projection(out), attn

class EncoderLayer(nn.Module):
    def __init__(self, attention, d_model, d_ff, dropout=0.1):
        super().__init__()
        self.attention = attention
        self.conv1 = nn.Conv1d(d_model, d_ff, 1)
        self.conv2 = nn.Conv1d(d_ff, d_model, 1)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)
        self.activation = F.gelu
    def forward(self, x):
        new_x, attn = self.attention(x, x, x)
        x = x + self.dropout(new_x)
        x = self.norm1(x)
        y = x.transpose(0, 1).transpose(1, 2)
        y = self.dropout(self.activation(self.conv1(y)))
        y = self.dropout(self.conv2(y))
        y = y.transpose(1, 2).transpose(0, 1)
        return self.norm2(x + y), attn

class Encoder(nn.Module):
    def __init__(self, attn_layers, norm_layer=None):
        super().__init__()
        self.attn_layers = nn.ModuleList(attn_layers)
        self.norm = norm_layer
    def forward(self, x):
        for layer in self.attn_layers: x, _ = layer(x)
        if self.norm is not None: x = self.norm(x)
        return x

# =========================
# Model 1: Informer (MultiTransAm)
# =========================
class MultiTransAm(nn.Module):
    def __init__(self, cypl=240, num_senders=3, factor=1, dropout=0.1,
                 d_model=12, n_heads=1, e_layers=1, d_ff=48,
                 decoder_hidden=64, activation='gelu',
                 conv_channels=None):
        super().__init__()
        if conv_channels is None:
            conv_channels = [128, 64]
        self.cypl = cypl
        self.num_senders = num_senders
        self.d_model = d_model
        self.decoder_hidden = decoder_hidden
        self.num_prev_bits = num_senders * 3

        self.input_proj = nn.Linear(1, d_model)
        self.pos_encoder = PositionalEncoding(d_model=d_model, max_len=cypl)
        self.conv_block = nn.Sequential(
            nn.Conv1d(1, conv_channels[0], 3, padding=1, stride=1),
            nn.ReLU(),
            nn.MaxPool1d(3, padding=1, stride=1),
            nn.Conv1d(conv_channels[0], conv_channels[1], 3, padding=1, stride=1),
            nn.ReLU(),
            nn.MaxPool1d(3, padding=1, stride=1),
            nn.Conv1d(conv_channels[1], d_model, 1, padding=0, stride=1),
            nn.ReLU(),
            nn.MaxPool1d(3, padding=1, stride=1)
        )
        Attn = ProbAttention
        self.encoder = Encoder([
            EncoderLayer(
                AttentionLayer(Attn(False, factor, attention_dropout=dropout), d_model, n_heads),
                d_model, d_ff, dropout
            ) for _ in range(e_layers)
        ], norm_layer=nn.LayerNorm(d_model))

        self.decoder = nn.Sequential(
            nn.Linear(cypl * d_model + self.num_prev_bits, decoder_hidden),
            nn.Tanh(),
            nn.Dropout(dropout),
            nn.Linear(decoder_hidden, num_senders * 2)
        )
        self._init_weights()

    def _init_weights(self):
        initrange = 0.4
        for m in self.decoder:
            if isinstance(m, nn.Linear):
                nn.init.uniform_(m.weight, -initrange, initrange)
                nn.init.zeros_(m.bias)
        nn.init.uniform_(self.input_proj.weight, -initrange, initrange)
        nn.init.zeros_(self.input_proj.bias)

    def forward(self, src, prev_bits):
        _, B, _ = src.shape
        x = self.input_proj(src)
        x = self.pos_encoder(x)
        conv_in = src.permute(1, 2, 0).contiguous()
        conv_out = self.conv_block(conv_in).permute(2, 0, 1).contiguous()
        enc_out = self.encoder(conv_out)
        enc_flat = enc_out.permute(1, 0, 2).reshape(B, -1)
        if prev_bits.dim() == 1:
            prev_bits = prev_bits.unsqueeze(0)
        combined = torch.cat([enc_flat, prev_bits], dim=1)
        dec_out = self.decoder(combined)
        return dec_out.view(B, self.num_senders, 2)

# =========================
# Model 2: TransformerModel
# =========================
class TransformerModel(nn.Module):
    def __init__(self, cypl=240, num_senders=3, factor=1, dropout=0.1, d_model=12, n_heads=1,
                 e_layers=1, d_ff=48, activation='gelu', decoder_hidden=120,
                 conv_channels=None):
        super().__init__()
        if conv_channels is None:
            conv_channels = [128, 64]
        self.cypl = cypl
        self.num_senders = num_senders
        self.d_model = d_model
        self.num_prev_bits = num_senders * 3

        self.input_proj = nn.Linear(1, d_model)
        self.pos_encoder = PositionalEncoding(d_model=d_model, max_len=cypl)
        self.conv_block = nn.Sequential(
            nn.Conv1d(in_channels=1, out_channels=conv_channels[0], kernel_size=3, padding=1, stride=1),
            nn.ReLU(), nn.MaxPool1d(kernel_size=3, padding=1, stride=1),
            nn.Conv1d(in_channels=conv_channels[0], out_channels=conv_channels[1], kernel_size=3, padding=1, stride=1),
            nn.ReLU(), nn.MaxPool1d(kernel_size=3, padding=1, stride=1),
            nn.Conv1d(in_channels=conv_channels[1], out_channels=d_model, kernel_size=1, padding=0, stride=1),
            nn.ReLU(), nn.MaxPool1d(kernel_size=3, padding=1, stride=1)
        )
        self.transformer_encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads if d_model % n_heads == 0 else 1,
            dim_feedforward=d_ff, dropout=dropout, activation=activation, batch_first=False
        )
        self.transformer_encoder = nn.TransformerEncoder(
            self.transformer_encoder_layer, num_layers=e_layers, norm=nn.LayerNorm(d_model)
        )
        self.decoder = nn.Sequential(
            nn.Linear(cypl * d_model + self.num_prev_bits, decoder_hidden),
            nn.Tanh(),
            nn.Dropout(dropout),
            nn.Linear(decoder_hidden, num_senders * 2)
        )
        self._init_weights()

    def _init_weights(self):
        initrange = 0.4
        for m in self.decoder:
            if isinstance(m, nn.Linear):
                nn.init.uniform_(m.weight, -initrange, initrange)
                nn.init.zeros_(m.bias)
        nn.init.uniform_(self.input_proj.weight, -initrange, initrange)
        nn.init.zeros_(self.input_proj.bias)

    def forward(self, src, prev_bits):
        _, B, _ = src.shape
        x = self.input_proj(src)
        x = self.pos_encoder(x)
        conv_in = src.permute(1, 2, 0).contiguous()
        conv_out = self.conv_block(conv_in).permute(2, 0, 1).contiguous()
        enc_out = self.transformer_encoder(conv_out)
        enc_flat = enc_out.permute(1, 0, 2).reshape(B, -1)
        if prev_bits.dim() == 1:
            prev_bits = prev_bits.unsqueeze(0)
        combined = torch.cat([enc_flat, prev_bits], dim=1)
        dec_out = self.decoder(combined)
        return dec_out.view(B, self.num_senders, 2)

# =========================
# Model 3: GRU_Plus_CNN_Transformer
# =========================
class GRU_Plus_CNN_Transformer(nn.Module):
    """Detector: CNN extracts detail, GRU modulates it, Transformer integrates.
    No MaxPool — preserves all molecular count details.
    Modulation gate: GRU output → sigmoid → per-channel gate weights on CNN features."""
    def __init__(self,
                 cypl=240,
                 num_senders=3,
                 dropout=0.1,
                 d_model=64,
                 num_layers=2,
                 n_heads=4,
                 transformer_layers=1,
                 use_last_k_steps=80,
                 decoder_hidden=120,
                 sim=20,
                 num_windows=4,
                 cnn_channels=[64, 128],
                 kernel_size=3,
                 **kwargs):
        super().__init__()
        self.cypl = cypl
        self.num_senders = num_senders
        self.d_model = d_model
        self.n_heads = n_heads
        self.use_last_k_steps = use_last_k_steps
        self.decoder_hidden = decoder_hidden
        self.num_prev_bits = num_senders * 3

        self.sim = sim
        self.num_windows = num_windows
        self.single_sender_len = num_windows * sim

        self.head_dim = d_model // n_heads
        assert self.head_dim * n_heads == d_model, 'd_model must be divisible by n_heads'
        assert 1 <= use_last_k_steps <= self.single_sender_len, 'use_last_k_steps must be in 1~80'

        # CNN branch (no MaxPool — keep all count detail)
        cnn_layers = []
        in_ch = 1
        for out_ch in cnn_channels:
            cnn_layers.append(
                nn.Conv1d(in_ch, out_ch, kernel_size=kernel_size, padding=kernel_size//2, stride=1))
            cnn_layers.append(nn.GELU())
            in_ch = out_ch
        cnn_layers.append(nn.Conv1d(in_ch, d_model, kernel_size=1, padding=0, stride=1))
        cnn_layers.append(nn.GELU())
        self.cnn_feature_extractor = nn.Sequential(*cnn_layers)

        self.input_proj = nn.Linear(1, d_model)
        self.input_dropout = nn.Dropout(dropout)
        self.pos_encoder = PositionalEncoding(d_model=d_model, max_len=self.single_sender_len)

        self.gru = nn.GRU(input_size=d_model, hidden_size=d_model,
                          num_layers=num_layers,
                          dropout=dropout if num_layers > 1 else 0.0,
                          batch_first=False)

        # Modulation gate: GRU output → sigmoid → gate CNN output
        self.mod_gate = nn.Linear(d_model, d_model)

        # Transformer with Pre-LN + residual
        self.trans_norm = nn.LayerNorm(d_model)
        transformer_encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=n_heads, dim_feedforward=d_model * 4,
            dropout=dropout, activation='gelu', batch_first=False, norm_first=True)
        self.transformer_encoder = nn.TransformerEncoder(
            transformer_encoder_layer, num_layers=transformer_layers,
            norm=nn.LayerNorm(d_model))
        self._causal_attention_mask = None

        self.decoder = nn.Sequential(
            nn.Linear(num_senders * use_last_k_steps * d_model + self.num_prev_bits, decoder_hidden),
            nn.GELU(), nn.Dropout(dropout),
            nn.Linear(decoder_hidden, num_senders * 2))
        self._init_weights()

    def _init_weights(self):
        for name, param in self.gru.named_parameters():
            if 'weight_ih' in name: nn.init.xavier_uniform_(param.data)
            elif 'weight_hh' in name: nn.init.orthogonal_(param.data)
            elif 'bias' in name: nn.init.zeros_(param.data)
        for m in self.modules():
            if isinstance(m, nn.Linear) and m is not self.gru:
                nn.init.xavier_uniform_(m.weight, gain=1.0)
                if m.bias is not None: nn.init.zeros_(m.bias)

    def _get_causal_mask(self, seq_len, device):
        if self._causal_attention_mask is None or self._causal_attention_mask.shape[0] != seq_len:
            mask = torch.triu(torch.ones(seq_len, seq_len, device=device), diagonal=1)
            mask = mask.masked_fill(mask == 1, float('-inf'))
            self._causal_attention_mask = mask
        return self._causal_attention_mask

    def forward(self, src, prev_bits):
        L, B, _ = src.shape

        x_reshaped = src.permute(1, 0, 2)
        x_split = x_reshaped.view(B, self.num_senders, self.single_sender_len, 1)
        x_merged = x_split.flatten(start_dim=0, end_dim=1)

        # CNN extracts local pulse detail
        x_cnn_in = x_merged.permute(0, 2, 1).contiguous()
        cnn_feat = self.cnn_feature_extractor(x_cnn_in)
        cnn_feat = cnn_feat.permute(2, 0, 1).contiguous()
        cnn_feat = self.pos_encoder(cnn_feat)

        # GRU reads temporal context → gate weights
        x_proj = self.input_proj(x_merged)
        gru_in = x_proj.permute(1, 0, 2).contiguous()
        gru_in = self.pos_encoder(gru_in)
        gru_out, _ = self.gru(gru_in)

        # Modulation: GRU decides how much to trust each CNN channel
        gate = torch.sigmoid(self.mod_gate(gru_out))
        x_final = cnn_feat * gate

        new_L, new_B, _ = x_final.shape
        x = self.input_dropout(x_final)

        # Transformer with residual connection
        causal_mask = self._get_causal_mask(new_L, x_final.device)
        x = x + self.transformer_encoder(self.trans_norm(x), mask=causal_mask)

        last_k_out = x[-self.use_last_k_steps:, :, :]
        enc_flat_merged = last_k_out.permute(1, 0, 2).reshape(new_B, -1)
        enc_flat = enc_flat_merged.view(B, self.num_senders * self.use_last_k_steps * self.d_model)

        if prev_bits.dim() == 1:
            prev_bits = prev_bits.unsqueeze(0)

        combined = torch.cat([enc_flat, prev_bits], dim=1)
        dec_out = self.decoder(combined)
        return dec_out.view(B, self.num_senders, 2)

# =========================
# Model class map
# =========================
MODEL_CLASS_MAP = {
    'informer': MultiTransAm,
    'TransformerModel': TransformerModel,
    'gru_plus_cnn': GRU_Plus_CNN_Transformer,
}

# =========================
# MolecularDataset
# =========================
class MolecularDataset(Dataset):
    def __init__(self, data_tensor, cypl, num_prev_bits, num_senders, feat_mean, feat_std):
        self.data = data_tensor
        self.cypl = cypl
        self.num_prev_bits = num_prev_bits
        self.num_senders = num_senders
        self.feat_mean = feat_mean.squeeze(0)
        self.feat_std = feat_std.squeeze(0)

    def __len__(self):
        return self.data.shape[0]

    def __getitem__(self, idx):
        row = self.data[idx]
        x_signal = row[:self.cypl]
        x_prev_bits = row[self.cypl : self.cypl + self.num_prev_bits]
        y = row[-self.num_senders:]
        x_signal = (x_signal - self.feat_mean) / self.feat_std
        return x_signal, x_prev_bits, y

# =========================
# Training utilities
# =========================
def accuracy_from_logits(logits, y):
    pred = logits.argmax(dim=2)
    return (pred == y.long()).float().mean().item()

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def build_seq_splits(seq_ids, train_ratio=0.8, val_ratio=0.1):
    unique_seq = torch.unique(seq_ids.cpu()).numpy().tolist()
    unique_seq = sorted(unique_seq)
    n_seq = len(unique_seq)
    assert n_seq >= 3, 'num_sequences must be >= 3'

    n_train = max(1, int(round(n_seq * train_ratio)))
    n_val = max(1, int(round(n_seq * val_ratio)))
    if n_train + n_val >= n_seq:
        n_val = 1
        n_train = n_seq - 2
    n_test = n_seq - n_train - n_val
    assert n_test >= 1, 'At least 1 sequence must be left for testing'

    train_seq = set(unique_seq[:n_train])
    val_seq = set(unique_seq[n_train:n_train + n_val])
    test_seq = set(unique_seq[n_train + n_val:])
    return train_seq, val_seq, test_seq

# =========================
# Main training function
# =========================
def train_model_once(data_tensor, seq_ids, all_true_bits, model_class, model_kwargs=None,
                     cypl=240, num_senders=3, epochs=60, batch_size=128,
                     device='cuda', seed=0, verbose=True,
                     lr=3e-4, weight_decay=5e-4,
                     train_ratio=0.8, val_ratio=0.1,
                     early_stop_patience=8,
                     num_workers=0,
                     device_ids=None,
                     use_amp=True,
                     compile_model=False):
    torch.manual_seed(seed)
    np.random.seed(seed)

    model_kwargs = dict(model_kwargs or {})
    train_seq, val_seq, test_seq = build_seq_splits(seq_ids, train_ratio=train_ratio, val_ratio=val_ratio)

    train_mask = torch.tensor([int(s.item() in train_seq) for s in seq_ids], dtype=torch.bool)
    val_mask = torch.tensor([int(s.item() in val_seq) for s in seq_ids], dtype=torch.bool)
    test_mask = torch.tensor([int(s.item() in test_seq) for s in seq_ids], dtype=torch.bool)

    train_data = data_tensor[train_mask]
    val_data = data_tensor[val_mask]
    test_data = data_tensor[test_mask]

    # Build per-sequence true_bits map for cross-sequence reset
    test_seq_ids = seq_ids[test_mask]
    test_true_bits_map = {}
    for s in test_seq:
        if s < len(all_true_bits):
            test_true_bits_map[s] = all_true_bits[s]

    num_prev_bits = num_senders * 3
    train_x = train_data[:, :cypl]
    feat_mean = train_x.mean(dim=0, keepdim=True)
    feat_std = train_x.std(dim=0, keepdim=True).clamp_min(1e-6)

    model = model_class(cypl=cypl, num_senders=num_senders, **model_kwargs)

    if compile_model and device.type == 'cuda':
        try:
            if verbose:
                print('    Compiling model (torch.compile)...', flush=True)
            model = torch.compile(model)
            if verbose:
                print('    Model compiled successfully', flush=True)
        except Exception as e:
            if verbose:
                print(f'    Compile failed, falling back to eager mode: {e}', flush=True)

    if device_ids is not None and len(device_ids) > 1:
        model = nn.DataParallel(model, device_ids=device_ids)
    model = model.to(device)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=lr,
        weight_decay=weight_decay,
        fused=True if device.type == 'cuda' else False
    )

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode='min', factor=0.5, patience=3, min_lr=lr * 0.1
    )

    train_dataset = MolecularDataset(train_data, cypl, num_prev_bits, num_senders, feat_mean, feat_std)
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True if num_workers > 0 else False,
        drop_last=True
    )

    val_dataset = MolecularDataset(val_data, cypl, num_prev_bits, num_senders, feat_mean, feat_std)
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True if num_workers > 0 else False
    )
    test_dataset = MolecularDataset(test_data, cypl, num_prev_bits, num_senders, feat_mean, feat_std)

    scaler = torch.amp.GradScaler('cuda', enabled=use_amp) if device.type == 'cuda' else None

    @torch.no_grad()
    def evaluate(loader):
        model.eval()
        total_loss, total_acc, steps = 0.0, 0.0, 0
        for x_signal, x_prev_bits, y in loader:
            src = x_signal.transpose(0, 1).unsqueeze(-1).contiguous().to(device, non_blocking=True)
            prev_bits = x_prev_bits.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)

            with torch.amp.autocast('cuda', enabled=use_amp):
                logits = model(src, prev_bits)
                loss = sum(F.cross_entropy(logits[:, s, :], y[:, s].long()) for s in range(num_senders)) / num_senders

            total_loss += loss.item()
            total_acc += accuracy_from_logits(logits, y)
            steps += 1

        if steps == 0:
            return float('inf'), 0.0
        return total_loss / steps, total_acc / steps

    @torch.no_grad()
    def evaluate_autoregressive():
        if len(test_true_bits_map) == 0:
            return float('inf'), [float('inf')] * num_senders

        model.eval()
        model_eval = model.module if hasattr(model, 'module') else model
        if hasattr(model_eval, '_orig_mod'):
            model_eval = model_eval._orig_mod

        all_preds = []
        all_labels = []
        current_seq_id = None
        history_manager = None
        seq_start_row = 0

        for row_idx_in_dataset in range(len(test_dataset)):
            seq_id = test_seq_ids[row_idx_in_dataset].item()

            # Cross-sequence reset: reinitialize BitHistoryManager per sequence
            if seq_id != current_seq_id:
                current_seq_id = seq_id
                seq_start_row = row_idx_in_dataset
                true_bits = test_true_bits_map.get(seq_id)
                if true_bits is None:
                    true_bits = list(test_true_bits_map.values())[0]
                history_manager = BitHistoryManager(true_bits, num_senders=num_senders, mode='test')

            j = (row_idx_in_dataset - seq_start_row) + 4

            x_signal, _, y = test_dataset[row_idx_in_dataset]
            src = x_signal.unsqueeze(0).transpose(0, 1).unsqueeze(-1).contiguous().to(device)

            prev_bits_np = history_manager.get_prev_bits(j)
            prev_bits = torch.tensor(prev_bits_np, dtype=torch.float32, device=device).reshape(1, -1)

            logits = model_eval(src, prev_bits)
            pred_bit = logits.argmax(dim=2).squeeze(0).cpu().numpy()

            history_manager.save_prediction(j, pred_bit)
            all_preds.append(pred_bit)
            all_labels.append(y.cpu().numpy())

        all_preds = np.array(all_preds)
        all_labels = np.array(all_labels)

        ber_each = []
        for s in range(num_senders):
            ber_s = np.mean(all_preds[:, s] != all_labels[:, s])
            ber_each.append(round(ber_s, 6))

        ber_avg = np.mean(ber_each)
        return ber_avg, ber_each

    best_state = copy.deepcopy(model.state_dict())
    best_val_loss = float('inf')
    best_epoch = 0
    bad_epochs = 0

    history = {
        'train_loss': [],
        'train_acc': [],
        'val_loss': [],
        'val_acc': []
    }

    if verbose:
        print(f'    Params: {count_parameters(model):,} | train={train_data.shape[0]} | val={val_data.shape[0]} | test={test_data.shape[0]}', flush=True)
        print(f'    AMP: {use_amp} | Compile: {compile_model} | batch_size={batch_size}', flush=True)

    for ep in range(1, epochs + 1):
        model.train()
        total_loss, total_acc, steps = 0.0, 0.0, 0

        for x_signal, x_prev_bits, y in train_loader:
            src = x_signal.transpose(0, 1).unsqueeze(-1).contiguous().to(device, non_blocking=True)
            prev_bits = x_prev_bits.to(device, non_blocking=True)
            y = y.to(device, non_blocking=True)

            # Scheduled sampling: flip history bits (5% → 15%)
            flip_prob = 0.05 + 0.10 * (ep - 1) / max(epochs - 1, 1)
            flip_mask = torch.rand_like(prev_bits) < flip_prob
            prev_bits_noisy = torch.where(flip_mask, 1.0 - prev_bits, prev_bits)

            optimizer.zero_grad(set_to_none=True)

            with torch.amp.autocast('cuda', enabled=use_amp):
                logits = model(src, prev_bits_noisy)
                loss = sum(F.cross_entropy(logits[:, s, :], y[:, s].long()) for s in range(num_senders)) / num_senders

            if use_amp and scaler is not None:
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                scaler.step(optimizer)
                scaler.update()
            else:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                optimizer.step()

            total_loss += loss.item()
            total_acc += accuracy_from_logits(logits.detach(), y)
            steps += 1

        train_loss = total_loss / max(1, steps)
        train_acc = total_acc / max(1, steps)
        val_loss, val_acc = evaluate(val_loader)
        scheduler.step(val_loss)

        history['train_loss'].append(train_loss)
        history['train_acc'].append(train_acc)
        history['val_loss'].append(val_loss)
        history['val_acc'].append(val_acc)

        if verbose and (ep == 1 or ep == epochs or ep % 5 == 0):
            print(f'    [epoch {ep:03d}] train_loss={train_loss:.4f} train_acc={train_acc:.4f} | val_loss={val_loss:.4f} val_acc={val_acc:.4f} | lr={optimizer.param_groups[0]["lr"]:.6f}', flush=True)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_epoch = ep
            best_state = copy.deepcopy(model.state_dict())
            bad_epochs = 0
        else:
            bad_epochs += 1
            if bad_epochs >= early_stop_patience:
                if verbose:
                    print(f'    [early stop] epoch={ep}, reverting to best epoch={best_epoch}', flush=True)
                break

    model_to_load = model.module if hasattr(model, 'module') else model
    if hasattr(model_to_load, '_orig_mod'):
        model_to_load._orig_mod.load_state_dict(best_state)
    else:
        model_to_load.load_state_dict(best_state)

    ber_overall, ber_each = evaluate_autoregressive()

    if verbose:
        print(f'    -> best_epoch={best_epoch} | Autoregressive BER:', flush=True)
        print(f'        Tx1 BER = {ber_each[0]:.6f}', flush=True)
        print(f'        Tx2 BER = {ber_each[1]:.6f}', flush=True)
        print(f'        Tx3 BER = {ber_each[2]:.6f}', flush=True)
        print(f'        Avg BER = {ber_overall:.6f}', flush=True)

    return ber_overall, ber_each, count_parameters(model), history

# =========================
# CLI Entry Point
# =========================
def main():
    parser = argparse.ArgumentParser(description='Parallel training worker')
    parser.add_argument('--model_name', required=True, choices=['informer', 'TransformerModel', 'gru_plus_cnn'])
    parser.add_argument('--data_path', required=True, help='Path to .pt file with data_tensor, seq_ids, all_true_bits')
    parser.add_argument('--result_path', required=True, help='Path to save result .pt file')
    parser.add_argument('--model_params_path', required=True, help='Path to JSON with model_kwargs, lr, weight_decay')
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--epochs', type=int, default=60)
    parser.add_argument('--batch_size', type=int, default=128)
    parser.add_argument('--early_stop_patience', type=int, default=15)
    parser.add_argument('--num_workers', type=int, default=0)
    parser.add_argument('--compile', action='store_true', default=False)
    args = parser.parse_args()

    # Load model params from JSON
    import json
    with open(args.model_params_path, 'r') as f:
        model_params = json.load(f)

    # Load data
    checkpoint = torch.load(args.data_path, map_location='cpu', weights_only=False)
    data_tensor = checkpoint['data_tensor']
    seq_ids = checkpoint['seq_ids']
    all_true_bits = checkpoint['all_true_bits']

    # Get model class
    model_cls = MODEL_CLASS_MAP[args.model_name]

    # Set device
    if args.device.startswith('cuda') and not torch.cuda.is_available():
        args.device = 'cpu'
    device = torch.device(args.device)

    # Train
    ber_overall, ber_each, param_count, history = train_model_once(
        data_tensor=data_tensor,
        seq_ids=seq_ids,
        all_true_bits=all_true_bits,
        model_class=model_cls,
        model_kwargs=model_params['model_kwargs'],
        epochs=args.epochs,
        batch_size=args.batch_size,
        device=device,
        seed=args.seed,
        verbose=True,
        lr=model_params['lr'],
        weight_decay=model_params['weight_decay'],
        train_ratio=0.8,
        val_ratio=0.1,
        early_stop_patience=args.early_stop_patience,
        num_workers=args.num_workers,
        device_ids=None,
        use_amp=True,
        compile_model=args.compile,
    )

    # Save result
    torch.save({
        'ber': ber_overall,
        'ber_each': ber_each,
        'param_count': param_count,
        'history': history,
    }, args.result_path)

    print(f'RESULT_SAVED: {args.result_path}', flush=True)

if __name__ == '__main__':
    main()
