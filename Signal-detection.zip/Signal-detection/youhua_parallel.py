#!/usr/bin/env python
# coding: utf-8
"""
Parallel training — 3D Brownian motion simulation channel model.

Replaces the erfc formula with full 3D simulation matching senior's
mobile_perfect_passive in CORE_sim_diffusion_3d_P2S_wAbsorption.m:

  - Anomalous diffusion: sigma = sqrt(2*alpha*D * t^(alpha-1) * delta_t)
  - Passive receiver (p_react=4): molecules counted when inside sphere,
    NOT absorbed — they continue diffusing
  - Receiver mobility with D_rx
  - Destruction limit for computational efficiency
  - Different molecule types per sender (different D_mol)

Usage: python youhua_parallel_sim.py [--device cuda] [--seed 1235]
                                    [--sim-molecules 100000] [--sim-steps-per-subslot 10]
"""

import argparse
import math
import time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import csv
import matplotlib.pyplot as plt
import copy
import os
import sys
import json
import shutil
import tempfile
import subprocess
import threading
import queue

plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 300

# =====================================================================
# Worker script path
# =====================================================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
WORKER_SCRIPT = os.path.join(SCRIPT_DIR, 'parallel_worker.py')


# =====================================================================
# Channel model — 3D Brownian Motion Simulation
# Matches senior's mobile_perfect_passive:
#   CORE_sim_diffusion_3d_P2S_wAbsorption.m  (p_react=4 branch)
# =====================================================================

def get_sender_params(num_senders, distance_um_vec,
                      r_rx_um=5.0,
                      D_mol_base=5e-9,
                      D_tx=1e-13,
                      D_rx=1e-13):
    """Sender parameters with physical diffusion coefficients (SI units).

    Based on prepare_vars4_diffusion_runners_PointSrc.m:
      D_mol : molecule diffusion coefficient (different per molecule type)
      D_tx  : transmitter mobility diffusion coefficient
      D_rx  : receiver mobility diffusion coefficient
      r_rx  : receiver radius (spherical, default 3 um)
    """
    params = []
    for i in range(num_senders):
        D_mol = D_mol_base - i * 6e-10
        if D_mol <= 0:
            raise ValueError(
                f"Tx{i+1}: D_mol={D_mol:.2e} <= 0. "
                f"D_mol_base={D_mol_base:.2e}, step=5e-10, "
                f"Tx3 would get {D_mol_base - 2*5e-10:.2e}. "
                f"Increase D_mol_base or reduce per-sender step.")
        params.append({
            'D_mol': D_mol,
            'D_tx': D_tx,
            'D_rx': D_rx,
            'r_rx': r_rx_um * 1e-6,
            'distance': float(distance_um_vec[i]) * 1e-6,
        })
    return params


def simulate_htab_3d(senders_params, sim=20, Ts=25e-3, memory=8,
                     alpha=1.5, steps_per_subslot=10, n_molecules=100000,
                     destruction_factor=7.0, seed=None, verbose=True):
    """Compute channel impulse response via 3D Brownian motion simulation.

    For each sender, releases n_molecules at its transmitter position at t=0
    and tracks anomalous diffusion with a passive mobile receiver.

    Matching senior's mobile_perfect_passive:
      - sigma_mol = sqrt(2*alpha*D_mol * t^(alpha-1) * delta_t)
      - sigma_rx  = sqrt(2*alpha*D_rx  * t^(alpha-1) * delta_t)
      - Passive receiver: molecules inside sphere are counted but NOT removed
      - Destruction limit: molecules beyond limit are discarded for efficiency
      - Works in um units (matching senior's convention)

    Args:
        senders_params: list of dicts (D_mol, D_tx, D_rx, r_rx, distance) in SI
        sim: sub-slots per symbol period
        Ts: symbol duration in seconds
        memory: number of past-symbol ISI taps
        alpha: anomalous diffusion exponent (1.5 matches senior)
        steps_per_subslot: simulation time steps within each sub-slot
        n_molecules: molecules to simulate per sender
        destruction_factor: factor for destruction radius (senior uses 7)
        seed: random seed for reproducibility
        verbose: print progress

    Returns:
        htab: (num_senders, memory+1, sim) — per-molecule arrival fraction
    """
    rng = np.random.default_rng(seed)
    num_senders = len(senders_params)

    subslot_duration = Ts / sim
    delta_t = subslot_duration / steps_per_subslot
    total_subslots = (memory + 1) * sim
    total_steps = total_subslots * steps_per_subslot

    htab = np.zeros((num_senders, memory + 1, sim), dtype=np.float64)

    for s, params in enumerate(senders_params):
        d_si = params['distance']           # m
        D_mol_si = params['D_mol']           # m^2/s
        D_rx_si = params['D_rx']             # m^2/s
        r_rx_si = params['r_rx']             # m

        # Convert to um units (matching senior's convention)
        d_um = d_si * 1e6
        D_mol = D_mol_si * 1e12              # m^2/s -> um^2/s
        D_rx = D_rx_si * 1e12
        r_rx = r_rx_si * 1e6
        rx_membrane_sq = r_rx ** 2

        # Transmitter at (d_um, 0, 0), receiver at origin initially
        tx_pos = np.array([d_um, 0.0, 0.0], dtype=np.float64)
        rx_pos = np.zeros(3, dtype=np.float64)

        # Release all molecules at transmitter position
        mol_pos = np.tile(tx_pos, (n_molecules, 1))  # (N, 3)

        # Destruction limit: 7*dist + 45 + r_rx  (senior's formula)
        destruction_limit = destruction_factor * d_um + 45.0 + r_rx
        destruction_limit_sq = destruction_limit ** 2

        # Accumulate counts per sub-slot
        counts = np.zeros(total_subslots, dtype=np.float64)

        n_active = n_molecules

        if verbose:
            print(f"    [Sim Tx{s+1}] d={d_um:.1f}um D_mol={D_mol:.1f}um2/s "
                  f"r_rx={r_rx:.1f}um N={n_molecules} steps={total_steps} "
                  f"dt={delta_t:.2e}s", flush=True)
            t_start = time.time()

        for step in range(1, total_steps + 1):
            t = step * delta_t

            # Anomalous diffusion step size
            # sigma = sqrt(2 * alpha * D * t^(alpha-1) * delta_t)
            t_pow = t ** (alpha - 1.0)
            var_mol = 2.0 * alpha * D_mol * t_pow * delta_t
            var_rx  = 2.0 * alpha * D_rx  * t_pow * delta_t
            if var_mol < 0 or var_rx < 0:
                raise ValueError(
                    f"Negative diffusion variance at step {step}: "
                    f"var_mol={var_mol:.3e} var_rx={var_rx:.3e} "
                    f"D_mol={D_mol} D_rx={D_rx} t_pow={t_pow:.3e} delta_t={delta_t:.3e}. "
                    f"Check that D_mol and D_rx are non-negative in get_sender_params().")
            sigma_mol = math.sqrt(var_mol)
            sigma_rx = math.sqrt(var_rx)

            # Move molecules (vectorized)
            mol_pos += rng.normal(0.0, sigma_mol, (n_active, 3))

            # Move receiver
            rx_pos += rng.normal(0.0, sigma_rx, 3)

            # Squared distances to receiver
            diff = mol_pos - rx_pos
            dist_sq = np.sum(diff * diff, axis=1)

            # Destruction: remove molecules too far away
            keep_mask = dist_sq < destruction_limit_sq
            n_destroyed = n_active - np.sum(keep_mask)
            if n_destroyed > 0:
                mol_pos = mol_pos[keep_mask]
                dist_sq = dist_sq[keep_mask]
                n_active = mol_pos.shape[0]

            # Count molecules inside receiver sphere (passive: don't remove)
            inside = np.sum(dist_sq <= rx_membrane_sq)
            subslot_idx = (step - 1) // steps_per_subslot
            if subslot_idx < total_subslots:
                counts[subslot_idx] += inside

            # Progress
            if verbose and step % (total_steps // 5) == 0:
                pct = step * 100 // total_steps
                print(f"      {pct}% step={step}/{total_steps} "
                      f"active={n_active} destroyed={n_destroyed}", flush=True)

        # Normalize to per-molecule per-subslot
        for delta in range(memory + 1):
            for k in range(sim):
                idx = delta * sim + k
                htab[s, delta, k] = counts[idx] / n_molecules

        if verbose:
            elapsed = time.time() - t_start
            total_counts = counts.sum()
            print(f"      done in {elapsed:.1f}s  total_counts={total_counts:.0f}  "
                  f"per_mol={total_counts/n_molecules:.4f}", flush=True)

    return htab


# =====================================================================
# Data generation  (uses htab from simulation above)
# =====================================================================

def generate_bits(num_senders, total_len, p1=0.5, rng=None):
    rng = rng or np.random.default_rng()
    X = rng.random((num_senders, total_len)) < p1
    return X.astype(np.int64)


def add_gaussian_noise_int(features_int, snr_db, rng=None):
    """Add Gaussian noise to integer features, then round back to integers.

    NOTE: uses axis=1 for signal_power, so noise sigma is proportional
    to each row's total power (dominated by the strongest sender).
    """
    rng = rng or np.random.default_rng()
    feats = features_int.astype(np.float64)
    signal_power = np.mean(feats**2, axis=1) + 1e-12
    sigma = np.sqrt(signal_power / (10.0 ** (snr_db / 10.0)))
    noise = rng.normal(loc=0.0, scale=sigma[:, None], size=feats.shape)
    noise = np.round(noise).astype(np.int64)
    out = feats.astype(np.int64) + noise
    out[out < 0] = 0
    return out.astype(np.int64)


def generate_dataset(num_samples, X_bits, htab, su_vec, sim=20, memory=8,
                     snr_db=0.0, seed=0):
    """Generate one dataset realisation with Poisson molecular counts.

    Feature layout (cypl = num_senders × 4 × sim):
      Block s encodes the received signal for molecule type s at the
      single receiver, across 4 time windows × sim sub-slots each.
      Molecule types are orthogonal — block s depends only on sender s's bits.

    Received count per sub-slot is Poisson with mean
      lambda = su_s * sum_delta htab[s, delta, k]
    summed over current bit (delta=0) and ISI (delta >= 1).
    """
    rng = np.random.default_rng(seed)
    num_senders = X_bits.shape[0]

    cypl = num_senders * 4 * sim
    num_prev_bits = num_senders * 3
    total_feat_dim = cypl + num_prev_bits

    feats = np.zeros((num_samples, total_feat_dim), dtype=np.float64)
    labels = np.zeros((num_samples, num_senders), dtype=np.int64)

    for row in range(num_samples):
        j = row + 4
        labels[row, :] = X_bits[:, j]

        for s in range(num_senders):
            su_s = int(su_vec[s])
            base = s * 4 * sim

            for w_idx, target_j in enumerate([j-3, j-2, j-1, j]):
                col_start = base + w_idx * sim

                for k in range(sim):
                    st = 0
                    # ISI from past bits (delta = 1 … memory)
                    for delta in range(1, memory + 1):
                        t_prev = target_j - delta
                        if t_prev >= 0 and X_bits[s, t_prev] == 1:
                            lam = su_s * htab[s, delta, k]
                            if lam > 0:
                                st += rng.poisson(lam)

                    # Current bit (delta = 0)
                    if target_j >= 0 and X_bits[s, target_j] == 1:
                        lam = su_s * htab[s, 0, k]
                        if lam > 0:
                            st += rng.poisson(lam)

                    feats[row, col_start + k] = st

        # Previous bits as side information (teacher forcing during training)
        prev_bits_start = cypl
        for s in range(num_senders):
            feats[row, prev_bits_start + s*3 + 0] = X_bits[s, j-3]
            feats[row, prev_bits_start + s*3 + 1] = X_bits[s, j-2]
            feats[row, prev_bits_start + s*3 + 2] = X_bits[s, j-1]

    feats[:, :cypl] = add_gaussian_noise_int(
        feats[:, :cypl].astype(np.int64), snr_db=snr_db, rng=rng)
    data = np.concatenate([feats, labels], axis=1).astype(np.float32)

    return torch.tensor(data, dtype=torch.float32), X_bits


def generate_dataset_multi_sequences(total_samples, num_sequences, num_senders,
                                     htab, su_vec, sim=20, memory=8,
                                     snr_db=0.0, seed=0, seq_id_offset=0):
    """Generate multiple independent bit sequences, each with its own channel."""
    assert num_sequences >= 1, 'num_sequences must be >= 1'
    base = total_samples // num_sequences
    rem = total_samples % num_sequences
    sample_counts = [base + (1 if i < rem else 0) for i in range(num_sequences)]

    all_data = []
    all_seq_ids = []
    all_true_bits = []
    master_rng = np.random.default_rng(seed)

    for seq_idx, seq_samples in enumerate(sample_counts):
        if seq_samples <= 0:
            continue
        seq_seed_bits = int(master_rng.integers(0, 2**31 - 1))
        seq_seed_data = int(master_rng.integers(0, 2**31 - 1))
        seq_rng = np.random.default_rng(seq_seed_bits)

        total_len = seq_samples + 4 + memory + 1
        X_bits = generate_bits(num_senders, total_len, p1=0.5, rng=seq_rng)

        seq_data, _ = generate_dataset(
            num_samples=seq_samples, X_bits=X_bits, htab=htab, su_vec=su_vec,
            sim=sim, memory=memory, snr_db=snr_db, seed=seq_seed_data,
        )
        all_data.append(seq_data)
        all_seq_ids.append(torch.full((seq_samples,), seq_idx + seq_id_offset, dtype=torch.long))
        all_true_bits.append(X_bits)

    return torch.cat(all_data, dim=0), torch.cat(all_seq_ids, dim=0), all_true_bits


# =====================================================================
# Candidate generation  (unchanged from original)
# =====================================================================
def project_to_sum_int(x, NS):
    x = np.maximum(np.array(x, dtype=np.float64), 0.0)
    if x.sum() <= 0:
        x = np.ones_like(x)
    y = x / x.sum() * NS
    y0 = np.floor(y).astype(int)
    diff = int(NS - y0.sum())
    if diff != 0:
        frac = y - y0
        order = np.argsort(-frac)
        if diff > 0:
            y0[order[:diff]] += 1
        else:
            order2 = np.argsort(frac)
            need = -diff
            for idx in order2:
                if need <= 0:
                    break
                if y0[idx] > 0:
                    dec = min(y0[idx], need)
                    y0[idx] -= dec
                    need -= dec
    return y0


def gen_candidates(N0, NS=30000, W=15, w_step=4000, seed=0):
    rng = np.random.default_rng(seed)
    N0 = project_to_sum_int(np.array(N0, dtype=np.float64), NS)
    cands = []
    n1 = max(1, W // 3)
    for _ in range(n1):
        alpha = rng.random(3)
        v = N0.astype(float) * alpha
        cands.append(project_to_sum_int(v, NS))
    n2 = max(1, W // 3)
    for _ in range(n2):
        raw = rng.uniform(-w_step, w_step, size=3)
        raw = raw - raw.mean()
        v = N0.astype(float) + raw
        v = np.maximum(v, 10)
        cands.append(project_to_sum_int(v, NS))
    n3 = W - n1 - n2
    for _ in range(n3):
        alpha = rng.uniform(0.2, 5.0, size=3)
        v = rng.dirichlet(alpha) * NS
        cands.append(project_to_sum_int(v, NS))
    uniq = []
    seen = set()
    for v in cands:
        t = tuple(v.tolist())
        if t not in seen:
            seen.add(t)
            uniq.append(v)
    while len(uniq) < W:
        alpha = rng.uniform(0.2, 5.0, size=3)
        v = rng.dirichlet(alpha) * NS
        v_int = project_to_sum_int(v, NS)
        t = tuple(v_int.tolist())
        if t not in seen:
            seen.add(t)
            uniq.append(v_int)
    return uniq[:W]


# =====================================================================
# Model param preview
# =====================================================================
def print_param_preview(model_config):
    sys.path.insert(0, SCRIPT_DIR)
    from parallel_worker import GRU_Plus_CNN_Transformer, count_parameters
    print('\nModel parameter counts:')
    # All replicas use the same GRU architecture — just show one
    cfg0 = list(model_config.values())[0]
    model = GRU_Plus_CNN_Transformer(cypl=240, num_senders=3, **cfg0['params'])
    n_params = count_parameters(model)
    print(f'  GRU_PLUS_CNN (×{len(model_config)} replicas): {n_params:,} params each')


# =====================================================================
# Parallel Training Launcher  (unchanged)
# =====================================================================
def run_parallel_training(data_tensor, seq_ids, all_true_bits,
                          trial, cand_idx, trial_seed, temp_dir,
                          model_config, model_name_list,
                          epochs=60, batch_size=128, early_stop_patience=15,
                          device_str='cuda:0'):
    if not os.path.exists(WORKER_SCRIPT):
        raise FileNotFoundError(
            f"Worker script not found: {WORKER_SCRIPT}\n"
            f"Please ensure parallel_worker.py is in: {SCRIPT_DIR}"
        )
    data_file = os.path.join(temp_dir, f'data_T{trial}_C{cand_idx}.pt')
    torch.save({
        'data_tensor': data_tensor,
        'seq_ids': seq_ids,
        'all_true_bits': all_true_bits,
    }, data_file)
    fsize_mb = os.path.getsize(data_file) / 1024 / 1024
    print(f'    [Parallel] Data saved: {fsize_mb:.1f} MB')

    processes = []
    result_files = {}
    for model_name in model_name_list:
        cfg = model_config[model_name]
        params_file = os.path.join(temp_dir, f'params_{model_name}_T{trial}_C{cand_idx}.json')
        with open(params_file, 'w') as f:
            json.dump({
                'model_kwargs': cfg['params'],
                'lr': cfg['train']['lr'],
                'weight_decay': cfg['train']['weight_decay'],
            }, f)
        result_file = os.path.join(temp_dir, f'result_{model_name}_T{trial}_C{cand_idx}.pt')
        result_files[model_name] = result_file
        worker_model = cfg.get('worker_model', model_name)
        seed_offset = cfg.get('seed_offset', 0)
        cmd = [
            sys.executable, WORKER_SCRIPT,
            '--model_name', worker_model,
            '--data_path', data_file,
            '--result_path', result_file,
            '--model_params_path', params_file,
            '--device', device_str,
            '--seed', str(trial_seed + 20000 + cand_idx + seed_offset),
            '--epochs', str(epochs),
            '--batch_size', str(batch_size),
            '--early_stop_patience', str(early_stop_patience),
            '--num_workers', '0',
        ]
        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONUTF8'] = '1'
        env.setdefault('PYDEVD_DISABLE_FILE_VALIDATION', '1')
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                             text=True, bufsize=1, env=env,
                             encoding='utf-8', errors='replace')
        processes.append((model_name, p))
    print(f'    [Parallel] Launched {len(processes)} workers, waiting...')

    def forward_output(model_name, pipe):
        for line in pipe:
            line = line.rstrip()
            if line:
                print(f'    [{model_name.upper()}] {line}')

    threads = []
    for model_name, p in processes:
        t = threading.Thread(target=forward_output, args=(model_name, p.stdout), daemon=True)
        t.start()
        threads.append(t)
    for model_name, p in processes:
        p.wait()
    for t in threads:
        t.join(timeout=5)

    trial_cand_ber = {}
    trial_cand_ber_each = {}
    all_histories = {}
    for model_name in model_name_list:
        result_file = result_files[model_name]
        if os.path.exists(result_file):
            try:
                result = torch.load(result_file, map_location='cpu', weights_only=False)
                trial_cand_ber[model_name] = result['ber']
                trial_cand_ber_each[model_name] = result['ber_each']
                all_histories[model_name] = result['history']
                print(f'    [Parallel] {model_name.upper()} done: BER={result["ber"]:.6f}')
            except Exception as e:
                print(f'    [Parallel] {model_name.upper()} result load failed: {e}')
                trial_cand_ber[model_name] = float('inf')
                trial_cand_ber_each[model_name] = [float('inf')] * 3
                all_histories[model_name] = None
        else:
            print(f'    [Parallel] {model_name.upper()} result file NOT FOUND!')
            trial_cand_ber[model_name] = float('inf')
            trial_cand_ber_each[model_name] = [float('inf')] * 3
            all_histories[model_name] = None

    for f in [data_file] + [
        os.path.join(temp_dir, f'params_{m}_T{trial}_C{cand_idx}.json')
        for m in model_name_list
    ]:
        try:
            if os.path.exists(f):
                os.remove(f)
        except OSError:
            pass
    return trial_cand_ber, all_histories, trial_cand_ber_each


# =====================================================================
# Plotting functions  (unchanged)
# =====================================================================
def plot_trial_ber_scatter(all_cand_ber_records, save_path=None):
    if save_path is None:
        save_path = "trial_ber_comparison_best_candidate.pdf"
    model_names = list(all_cand_ber_records.keys())
    if len(model_names) == 0:
        print("No model data, skipping plot"); return
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd']
    markers = ['o', 's', '^', 'D', 'v']
    num_trials = max(len(all_cand_ber_records[name]) for name in model_names)
    if num_trials == 0: return
    plt.figure(figsize=(14, 6))
    for i, name in enumerate(model_names):
        trial_indices, best_ber_values = [], []
        for t_idx in range(num_trials):
            if t_idx >= len(all_cand_ber_records[name]): continue
            cand_bers = all_cand_ber_records[name][t_idx]
            if len(cand_bers) == 0: continue
            trial_indices.append(t_idx + 1)
            best_ber_values.append(min(cand_bers))
        plt.plot(trial_indices, best_ber_values,
                 marker=markers[i % len(markers)],
                 linestyle='-', linewidth=1.5, markersize=6,
                 color=colors[i % len(colors)], label=name, alpha=0.8)
    plt.xlabel('Trial Index', fontsize=12)
    plt.ylabel('Best BER (per Trial)', fontsize=12)
    plt.title('Model Performance Comparison (Best Candidate per Trial)', fontsize=14)
    if num_trials > 10:
        plt.xticks(range(0, num_trials + 1, 10))
    else:
        plt.xticks(range(1, num_trials + 1))
    plt.legend(fontsize=10, bbox_to_anchor=(1.01, 1), loc='upper left')
    plt.grid(True, linestyle='--', alpha=0.5)
    plt.tight_layout()
    plt.savefig(save_path, format='pdf', bbox_inches='tight')
    print(f"Saved: {save_path}"); plt.close()


def plot_convergence_comparison(all_histories, trial_idx=0, cand_idx=0, save_path=None):
    if save_path is None:
        save_path = f"convergence_comparison_trial{trial_idx+1}_cand{cand_idx+1}.pdf"
    model_names = list(all_histories.keys())
    if len(model_names) == 0:
        print("No convergence data, skipping plot"); return
    colors = ['#1f77b4', '#ff7f0e', '#2ca02c', '#d62728', '#9467bd', '#8c564b']
    hist_data = {}
    for m in model_names:
        if len(all_histories[m]) > 0 and all_histories[m][-1] is not None:
            hist_data[m] = all_histories[m][-1]
    if len(hist_data) == 0: return
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    titles = ['Training Loss', 'Validation Loss', 'Training Accuracy', 'Validation Accuracy']
    keys = ['train_loss', 'val_loss', 'train_acc', 'val_acc']
    positions = [(0,0), (0,1), (1,0), (1,1)]
    for (r, c), title, key in zip(positions, titles, keys):
        ax = axes[r, c]
        for i, name in enumerate(hist_data.keys()):
            eps = range(1, len(hist_data[name][key])+1)
            ax.plot(eps, hist_data[name][key], label=name,
                    color=colors[i % len(colors)], linewidth=2)
        ax.set_title(f'{title} (T{trial_idx+1} C{cand_idx+1})', fontsize=14, fontweight='bold')
        ax.set_xlabel('Epoch'); ax.set_ylabel(title.split()[-1])
        ax.legend(); ax.grid(True, linestyle='--', alpha=0.6)
    plt.suptitle('Model Convergence Comparison', fontsize=16, y=1.02)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"Saved convergence plot: {save_path}"); plt.close()


def save_dnn_train_data_to_csv(data_list, model_name, csv_path=None):
    if csv_path is None:
        csv_path = f"dnn_train_data_{model_name}.csv"
    with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(['distance1_um', 'distance2_um', 'distance3_um',
                          'N1', 'N2', 'N3', 'Tx1_BER', 'Tx2_BER', 'Tx3_BER'])
        for dist_um, best_N, ber_each in data_list:
            writer.writerow([
                round(dist_um[0],4), round(dist_um[1],4), round(dist_um[2],4),
                int(best_N[0]), int(best_N[1]), int(best_N[2]),
                round(ber_each[0], 6), round(ber_each[1], 6), round(ber_each[2], 6),
            ])
    print(f"DNN training data saved: {csv_path}")


# =====================================================================
# Model config  (must match parallel_worker.py MODEL_CLASS_MAP)
# 3 identical GRU replicas with different seeds → independent training runs
# =====================================================================
MODEL_NAME_LIST = ['gru_1', 'gru_2', 'gru_3']

GRU_PARAMS = {
    'd_model': 16, 'num_layers': 2, 'n_heads': 4,
    'transformer_layers': 1, 'use_last_k_steps': 50,
    'dropout': 0.20, 'decoder_hidden': 48,
    'sim': 20, 'num_windows': 4,
    'cnn_channels': [24, 32], 'kernel_size': 21,
}
GRU_TRAIN = {'lr': 1.25e-4, 'weight_decay': 2.5e-4}

MODEL_CONFIG = {
    'gru_1': {
        'worker_model': 'gru_plus_cnn',
        'params': GRU_PARAMS,
        'train': GRU_TRAIN,
        'seed_offset': 7,
    },
    'gru_2': {
        'worker_model': 'gru_plus_cnn',
        'params': GRU_PARAMS,
        'train': GRU_TRAIN,
        'seed_offset': 1777,
    },
    'gru_3': {
        'worker_model': 'gru_plus_cnn',
        'params': GRU_PARAMS,
        'train': GRU_TRAIN,
        'seed_offset': 2777,
    },
}


# =====================================================================
# Main — pipelined: CPU pre-sim while GPU trains
# =====================================================================
def main():
    parser = argparse.ArgumentParser(
        description='Parallel Molecular MIMO Training — 3D Simulation Channel '
                    '(pipelined: CPU pre-simulation + GPU training)')
    parser.add_argument('--device', type=str, default='cuda')
    parser.add_argument('--seed', type=int, default=1777)
    parser.add_argument('--sim-molecules', type=int, default=100000,
                        help='Number of molecules per sender in 3D simulation')
    parser.add_argument('--sim-steps-per-subslot', type=int, default=10,
                        help='Simulation time steps within each sub-slot')
    parser.add_argument('--sim-alpha', type=float, default=1.5,
                        help='Anomalous diffusion exponent')
    args, _ = parser.parse_known_args()

    if args.device == 'cuda' and not torch.cuda.is_available():
        args.device = 'cpu'
    device = torch.device(args.device)
    print(f'Device: {device}')
    print(f'Worker script: {WORKER_SCRIPT}')

    if not os.path.exists(WORKER_SCRIPT):
        print(f'\n{"="*60}')
        print(f'ERROR: parallel_worker.py not found!')
        print(f'Expected at: {WORKER_SCRIPT}')
        print(f'Please ensure parallel_worker.py is in the same directory.')
        print(f'{"="*60}')
        sys.exit(1)

    # ==================== Experiment parameters ====================
    base_dist = np.array([11.5, 12.5, 13.5], dtype=np.float64)
    dist_perturb_um = 0.5
    num_dist_trials = 1000
    NS = 30000
    N0 = np.array([10000, 10000, 10000], dtype=np.float64)
    num_candidates = 6

    total_samples = 15000
    num_sequences = 10
    n_train_val_seqs = 6
    n_test_seqs = 4
    epochs = 50
    batch_size = 128
    early_stop_patience = 20
    snr_db = 6
    memory = 3

    sim_molecules = args.sim_molecules
    sim_steps_per_subslot = args.sim_steps_per_subslot
    sim_alpha = args.sim_alpha

    # ==================== Param preview ====================
    print_param_preview(MODEL_CONFIG)

    # ==================== Start ====================
    print('\n' + '=' * 72)
    print('== Pipeline Training: 3D Brownian Motion Simulation Channel ==')
    print(f'Base distances: {base_dist.tolist()} um')
    print(f'Ns: {NS} | Candidates: {num_candidates} | Trials: {num_dist_trials}')
    print(f'Samples: {total_samples} | Sequences: {num_sequences} '
          f'(train/val={n_train_val_seqs}, test={n_test_seqs})')
    print(f'SNR: {snr_db} dB')
    print(f'Channel: 3D anomalous diffusion (alpha={sim_alpha}), passive receiver')
    print(f'  {sim_molecules} molecules/sender, {sim_steps_per_subslot} steps/sub-slot')
    print(f'Epochs: {epochs} | Batch: {batch_size} | '
          f'Early stop patience: {early_stop_patience}')
    print(f'Models: {len(MODEL_NAME_LIST)} GRU replicas × 3 candidates = '
          f'{len(MODEL_NAME_LIST)}-way parallel per round')
    print(f'Pipeline: CPU pre-sims while GPU trains (buffer=1 trial ahead)')
    print('=' * 72)

    N0 = project_to_sum_int(N0, NS)
    dnn_data_records = []    # best per trial (200 rows)
    all_cand_records = []    # all candidates (1200 rows)
    all_ber_records = []     # per-trial best BER

    temp_dir = tempfile.mkdtemp(prefix='pipeline_train_')
    print(f'\nTemp directory: {temp_dir}')

    t_total_start = time.time()

    # ==================== Helper: simulate one trial ====================
    def simulate_one_trial(trial, trial_seed):
        """Run channel sim + generate 6 candidate data → save to temp files.
        Returns dict with keys: trial, dist_um, cands, data_paths[6], htab info.
        """
        rng = np.random.default_rng(trial_seed)
        perturb = rng.uniform(-dist_perturb_um, dist_perturb_um, size=3)
        dist_um = np.maximum(base_dist + perturb, 0.1)

        t0 = time.time()
        print(f'\n  [PreSim T{trial}] dist={dist_um.round(4).tolist()}  '
              f'— simulating channels...', flush=True)

        senders_params = get_sender_params(3, dist_um)

        htab_train = simulate_htab_3d(
            senders_params, sim=20, Ts=25e-3, memory=memory,
            alpha=sim_alpha, steps_per_subslot=sim_steps_per_subslot,
            n_molecules=sim_molecules, seed=trial_seed, verbose=False)

        htab_test = simulate_htab_3d(
            senders_params, sim=20, Ts=25e-3, memory=memory,
            alpha=sim_alpha, steps_per_subslot=sim_steps_per_subslot,
            n_molecules=sim_molecules, seed=trial_seed + 100000, verbose=False)

        cands = gen_candidates(N0, NS=NS, W=num_candidates, seed=trial_seed + 999)

        # Save data for each candidate
        trial_dir = os.path.join(temp_dir, f'trial_{trial}')
        os.makedirs(trial_dir, exist_ok=True)
        data_paths = []

        for ci, N in enumerate(cands):
            n_samp_train = total_samples * n_train_val_seqs // num_sequences
            d_tr, s_tr, b_tr = generate_dataset_multi_sequences(
                total_samples=n_samp_train, num_sequences=n_train_val_seqs,
                num_senders=3, htab=htab_train, su_vec=N,
                sim=20, memory=memory, snr_db=snr_db,
                seed=trial_seed + 10000 + ci, seq_id_offset=0)

            n_samp_test = total_samples - n_samp_train
            d_te, s_te, b_te = generate_dataset_multi_sequences(
                total_samples=n_samp_test, num_sequences=n_test_seqs,
                num_senders=3, htab=htab_test, su_vec=N,
                sim=20, memory=memory, snr_db=snr_db,
                seed=trial_seed + 20000 + ci, seq_id_offset=n_train_val_seqs)

            data = torch.cat([d_tr, d_te], dim=0)
            seq_ids = torch.cat([s_tr, s_te], dim=0)
            bits = b_tr + b_te

            path = os.path.join(trial_dir, f'data_C{ci}.pt')
            torch.save({
                'data_tensor': data, 'seq_ids': seq_ids,
                'all_true_bits': bits, 'cand_idx': ci, 'N': N,
            }, path)
            data_paths.append(path)

        elapsed = time.time() - t0
        n_total = sum(N.sum() for N in cands) / len(cands)
        print(f'  [PreSim T{trial}] done in {elapsed:.1f}s  '
              f'(6 datasets, avg sum N={n_total:.0f})', flush=True)

        return {
            'trial': trial, 'dist_um': dist_um,
            'cands': cands, 'data_paths': data_paths,
            'senders_params': senders_params,
            'htab_train': htab_train, 'htab_test': htab_test,
        }

    # ==================== Helper: launch one GRU worker ====================
    def launch_worker(model_label, data_path, worker_seed, result_path):
        """Launch a single GRU subprocess, return Popen object."""
        cfg = MODEL_CONFIG[model_label]
        worker_model = cfg.get('worker_model', model_label)
        seed_offset = cfg.get('seed_offset', 0)

        params_file = result_path.replace('.pt', '_params.json')
        with open(params_file, 'w') as f:
            json.dump({
                'model_kwargs': cfg['params'],
                'lr': cfg['train']['lr'],
                'weight_decay': cfg['train']['weight_decay'],
            }, f)

        env = os.environ.copy()
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONUTF8'] = '1'
        env.setdefault('PYDEVD_DISABLE_FILE_VALIDATION', '1')

        cmd = [
            sys.executable, WORKER_SCRIPT,
            '--model_name', worker_model,
            '--data_path', data_path,
            '--result_path', result_path,
            '--model_params_path', params_file,
            '--device', str(device),
            '--seed', str(worker_seed + seed_offset),
            '--epochs', str(epochs),
            '--batch_size', str(batch_size),
            '--early_stop_patience', str(early_stop_patience),
            '--num_workers', '0',
        ]
        return subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, bufsize=1, env=env,
                                encoding='utf-8', errors='replace')

    # ==================== Helper: collect worker results ====================
    def collect_worker(model_label, p, result_path):
        """Wait for worker, read stdout, load result."""
        stdout_lines = []
        for line in p.stdout:
            line = line.rstrip()
            if line:
                stdout_lines.append(line)
        p.wait()

        if p.returncode != 0 or not os.path.exists(result_path):
            print(f'    [{model_label}] FAILED (rc={p.returncode})')
            return float('inf'), [float('inf')] * 3, None

        result = torch.load(result_path, map_location='cpu', weights_only=False)
        ber = result['ber']
        ber_each = result['ber_each']
        history = result.get('history')
        # Print summary (last line only to avoid clutter)
        for line in stdout_lines:
            if 'Avg BER' in line or 'best_epoch' in line:
                print(f'    [{model_label}] {line}')
        return ber, ber_each, history

    # ==================== Pre-simulation background worker ====================
    presim_queue = queue.Queue(maxsize=1)  # buffer 1 trial ahead

    def presim_bg_worker(start_trial):
        """Background thread: pre-simulate trials while GPU trains."""
        for trial in range(start_trial, num_dist_trials):
            trial_seed = args.seed + trial
            pre_data = simulate_one_trial(trial, trial_seed)
            presim_queue.put(pre_data)

    # =================================================================
    # Main pipeline loop
    # =================================================================
    try:
        bg_thread = None

        for trial in range(num_dist_trials):
            # --- Get pre-sim data ---
            if trial == 0:
                # Trial 0: run synchronously
                trial_seed = args.seed
                pre_data = simulate_one_trial(0, trial_seed)
                # Start background pre-sim for trial 1+
                bg_thread = threading.Thread(
                    target=presim_bg_worker, args=(1,), daemon=True)
                bg_thread.start()
            else:
                # Trial 1+: get pre-prepared data from queue
                print(f'\n  [Pipeline] waiting for pre-sim data...', flush=True)
                pre_data = presim_queue.get()
                print(f'  [Pipeline] got pre-sim data for trial {trial}', flush=True)

            trial_seed = args.seed + pre_data['trial']
            dist_um = pre_data['dist_um']
            cands = pre_data['cands']
            data_paths = pre_data['data_paths']

            print(f'\n{"="*60}')
            print(f'=== Trial {pre_data["trial"] + 1}/{num_dist_trials}  '
                  f'dist={dist_um.round(4).tolist()} ===')
            print(f'{"="*60}')

            # Print channel IR summary
            for s in range(3):
                p = pre_data['senders_params'][s]
                d_um_s = p['distance'] * 1e6
                F_inf = p['r_rx'] / p['distance']
                htab_s = pre_data['htab_train'][s]
                print(f"  Tx{s+1}  d={d_um_s:.1f}um  "
                      f"F(inf)={F_inf:.4f}  sum(htab)={htab_s.sum():.4f}  |  "
                      f"d0={htab_s[0,:].mean():.4e}  d1={htab_s[1,:].mean():.4e}")

            # --- 2 rounds of 3-way parallel training ---
            trial_cand_results = {}  # ci → list of (ber, ber_each, hist) from replicas

            for round_idx in range(2):
                ci_list = [round_idx * 3 + i for i in range(3)]
                print(f'\n  --- Round {round_idx+1}/2: '
                      f'cands {[ci+1 for ci in ci_list]} ---')
                t_round = time.time()

                # Launch 3 workers in parallel (one per candidate)
                round_procs = {}
                round_result_paths = {}
                for i, ci in enumerate(ci_list):
                    label = MODEL_NAME_LIST[i]  # gru_1, gru_2, gru_3
                    result_path = os.path.join(
                        temp_dir, f'result_T{pre_data["trial"]}_R{round_idx}_C{ci}.pt')
                    worker_seed = trial_seed + 20000 + ci
                    p = launch_worker(label, data_paths[ci], worker_seed, result_path)
                    round_procs[(ci, label)] = p
                    round_result_paths[(ci, label)] = result_path

                # Forward stdout (interleaved)
                def forward_output(tag, pipe):
                    for line in pipe:
                        line = line.rstrip()
                        if line and ('epoch' in line.lower() or 'best' in line.lower()
                                     or 'BER' in line or 'RESULT' in line):
                            print(f'    [{tag}] {line}')

                fwd_threads = []
                for (ci, label), p in round_procs.items():
                    t = threading.Thread(
                        target=forward_output,
                        args=(f'{label}_C{ci+1}', p.stdout), daemon=True)
                    t.start()
                    fwd_threads.append(t)

                # Collect results
                for (ci, label), p in round_procs.items():
                    ber, ber_each, hist = collect_worker(
                        label, p, round_result_paths[(ci, label)])
                    if ci not in trial_cand_results:
                        trial_cand_results[ci] = []
                    trial_cand_results[ci].append((ber, ber_each, hist))

                for t in fwd_threads:
                    t.join(timeout=3)

                print(f'    Round {round_idx+1} done in {time.time()-t_round:.1f}s')

            # --- Find best allocation for this trial ---
            best_ber = float('inf')
            best_N = None
            best_ber_each = None
            print(f'\n  --- Trial {pre_data["trial"]+1} Best per Candidate ---')
            for ci in range(num_candidates):
                results = trial_cand_results.get(ci, [])
                if not results:
                    print(f'    Cand {ci+1}: NO RESULTS')
                    continue
                # Take best BER across 3 GRU replicas for this candidate
                best_idx = np.argmin([r[0] for r in results])
                ber_c, ber_each_c, _ = results[best_idx]
                N_c = cands[ci]
                print(f'    Cand {ci+1}: N={N_c.tolist()}  '
                      f'best_BER={ber_c:.6f}  (replica {best_idx+1})')
                if ber_c < best_ber:
                    best_ber = ber_c
                    best_N = N_c
                    best_ber_each = ber_each_c

            dnn_data_records.append((dist_um.tolist(), best_N, best_ber_each))
            all_ber_records.append(best_ber)
            # Save ALL candidates for this trial (not just best)
            for ci in range(num_candidates):
                results = trial_cand_results.get(ci, [])
                if not results: continue
                best_idx = np.argmin([r[0] for r in results])
                ber_c, ber_each_c, _ = results[best_idx]
                all_cand_records.append((dist_um.tolist(), cands[ci], ber_each_c))
            print(f'\n  >>> Trial Best: N*={best_N}  BER={best_ber:.6f}')

            # Clean up this trial's data files
            trial_dir = os.path.join(temp_dir, f'trial_{pre_data["trial"]}')
            shutil.rmtree(trial_dir, ignore_errors=True)

    finally:
        # Clean up any remaining trial dirs
        for d in os.listdir(temp_dir):
            dpath = os.path.join(temp_dir, d)
            if os.path.isdir(dpath) and d.startswith('trial_'):
                shutil.rmtree(dpath, ignore_errors=True)
        # Clean result files
        for f in os.listdir(temp_dir):
            if f.startswith('result_') or f.startswith('params_'):
                os.remove(os.path.join(temp_dir, f))
        print(f'\nTemp directory cleaned: {temp_dir}')

    t_total = time.time() - t_total_start

    print(f'\n{"="*72}')
    print(f'ALL DONE - Total time: {t_total:.1f}s ({t_total/60:.1f}min)')
    print(f'  Trials: {num_dist_trials} | '
          f'Avg per trial: {t_total/num_dist_trials:.1f}s')
    print(f'{"="*72}')

    # ==================== Save CSV files ====================
    print('\nSaving DNN training data:')

    # File 1: best per trial (200 rows) — for Stage 2 DNN allocation training
    csv_path = 'dnn_train_data_gru_only.csv'
    with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(['distance1_um', 'distance2_um', 'distance3_um',
                          'N1', 'N2', 'N3', 'Tx1_BER', 'Tx2_BER', 'Tx3_BER'])
        for dist_um, best_N, ber_each in dnn_data_records:
            writer.writerow([
                round(dist_um[0], 4), round(dist_um[1], 4), round(dist_um[2], 4),
                int(best_N[0]), int(best_N[1]), int(best_N[2]),
                round(ber_each[0], 6), round(ber_each[1], 6), round(ber_each[2], 6),
            ])
    print(f'  Saved: {csv_path}  ({len(dnn_data_records)} rows — best per trial)')

    # File 2: all candidates (1200 rows) — for Stage 1 BER predictor training
    csv_path2 = 'dnn_train_data_gru_all_candidates.csv'
    with open(csv_path2, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(['distance1_um', 'distance2_um', 'distance3_um',
                          'N1', 'N2', 'N3', 'Tx1_BER', 'Tx2_BER', 'Tx3_BER'])
        for dist_um, N, ber_each in all_cand_records:
            writer.writerow([
                round(dist_um[0], 4), round(dist_um[1], 4), round(dist_um[2], 4),
                int(N[0]), int(N[1]), int(N[2]),
                round(ber_each[0], 6), round(ber_each[1], 6), round(ber_each[2], 6),
            ])
    print(f'  Saved: {csv_path2}  ({len(all_cand_records)} rows — all candidates)')

    # ==================== Statistics ====================
    print('\n' + '='*60)
    print('Global Statistics (GRU only):')
    print('='*60)
    ber_arr = np.array(all_ber_records)
    print(f'  Mean BER: {ber_arr.mean():.6f}  |  '
          f'Std: {ber_arr.std():.6f}  |  '
          f'Min: {ber_arr.min():.6f}  |  '
          f'Max: {ber_arr.max():.6f}')

    print('\nDone!')


if __name__ == '__main__':
    main()
